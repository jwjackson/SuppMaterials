"# SuppMaterials" 

This repository contains the supporting code for:

Jackson JW, VanderWeele TJ. "Decomposition analysis to identify targets for reducing disparities." Epidemiology 2018 (in press)

The data come from the 1979 and 1997 National Longitudinal Survey of Youth, following a [seminal paper by Roland Fryer](https://scholar.harvard.edu/fryer/publications/racial-inequality-21st-century-declining-significance-discrimination). They are available from the [Bureau of Labor Statistics](https://www.bls.gov/nls/). Following the instructions there, you can use the tagsets `NLSY79_FRYER.NLSY79` and `NLSY97_FRYER.NLSY97` to select the appropriate variables and download the data from each survey (save them as `NLSY79_FRYER` and `NLYSY97_FRYER`). You can then use the SAS files `NLSY79.sas` and `NLSY97.sas` here (or the ones provided by BLS) to create the raw SAS datasets `data79_raw` and `data97_raw`. The SAS file `export_to_R.sas` takes these files, creates the analytic datasets in SAS, and exports them as `nlsy79.csv` and `nlsy97.csv`. The file `decompose.r` takes these datasets, imports them to R, and runs the decomposition analysis.