####################
##READ IN PACKAGES##
####################

remove(list=ls())

#library(Hmisc)
library(tidyr)
library(dplyr)
library(arm)
#library(geepack)
#library(sandwich)

################
##READ IN DATA##
################


path <- "C:\\folders\\myfolders\\"

data79	<- read.csv(paste(path,"nlsy79.csv",sep=""))
data97	<- read.csv(paste(path,"nlsy97.csv",sep=""))

data79 <- mutate(data79,highgrade2=highgrade*highgrade)
data97 <- mutate(data97,highgrade2=highgrade*highgrade)

###################
## RECORD OUTPUT ##
###################

sink(file=paste(path,"decomp_R_results_3Covariates_2016_01_19_repro.txt",sep=""),type="output")

#######################################
#FUNCTION TO OUTPUT EACH DECOMPOSITION#
#######################################

#CONTINUOUS OUTCOMES#

decompose.x.con <- function (indata,year,Y,X1,X1.NA=NULL,X2,X2.NA=NULL,X3,X3.NA=NULL,M1=NULL,M2=NULL,M.NA=NULL,silent="no") {
  
    #indata=data79
    #year=79
    #Y="logwages"
    #M1="highgrade"
    #M2="highgrade2"
    #M.NA="miss_highgrade"
    #X1="educ_mom"
    #X1.NA="miss_educ_mom"
    #X2="hhincome"
    #X2.NA="miss_hhincome"
    #X3="povstatus"
    #X3.NA="miss_povstatus"
  
  if (year==79) {
    
    #RENAME INPUT VARIABLES#
    
    indata <- rename_(indata,y=Y,a="black",w1="age",w2="hispanic",m1=M1,m2=M2,m.na=M.NA,x1=X1,x1.na=X1.NA,x2=X2,x2.na=X2.NA,x3=X3,x3.na=X3.NA)
    indata <- indata %>% subset(w2==0)
    #FIT MODELS#
    
    #Fit model 1
    
    model1 <- glm(data=indata, formula= y ~ a
                  +w1, family=gaussian("identity")) 
    
    #Fit model 2
    
    model2 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  , family=gaussian("identity")) 
    
    #Fit model 3
    
    model3 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  , family=gaussian("identity")) 
    
    #Fit model 4
    
    model4 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  , family=gaussian("identity")) 		
    
    #Fit model 5
    
    model5 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  +m1+m2+m.na
                  , family=gaussian("identity"))
    
    #Fit model 6 -- Fryer
    
    model6 <- glm(data=indata, formula= y ~ a
                  +w1
                  +m1+m2+m.na, family=gaussian("identity")) 
    
    
  } else if (year==97) {
    
    #   indata=data97
    #   year=97
    #	  Y="logwages"
    #	  M1="afqt_std"
    #	  M2="afqt_std2"
    #	  M.NA="miss_afqt"
    #	  X1="educ_mom"
    #	  X1.NA="miss_educ_mom"
    #	  X2="hhincome"
    #	  X2.NA="miss_hhincome"
    #	  X3="networth"
    #	  X3.NA="miss_networth"
    
    indata <- rename_(indata,y=Y,a="black",w1="age",w2="hispanic",w3="mixed",m1=M1,m2=M2,m.na=M.NA,x1=X1,x1.na=X1.NA,x2=X2,x2.na=X2.NA,x3=X3,x3.na=X3.NA)
    indata <- indata %>% subset(w2==0 & w3==0)
    
    #Fit model 1
    
    model1 <- glm(data=indata, formula= y ~ a
                  +w1, family=gaussian("identity"))
    
    #Fit model 2
    
    model2 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  , family=gaussian("identity"))
    
    #Fit model 3
    
    model3 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  , family=gaussian("identity"))											
    #Fit model 4
    
    model4 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  , family=gaussian("identity"))
    
    #Fit model 5
    
    model5 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  +m1+m2+m.na
                  , family=gaussian("identity"))
    
    #Fit model 6 -- Fryer
    
    model6 <- glm(data=indata, formula= y ~ a
                  +w1
                  +m1+m2+m.na, family=gaussian("identity"))
    
    
  }
  
  #PRINT RACE PARAMETER#
  
  A <- coef(model1)
  A.SE <- se.coef(model1)
  
  B <- coef(model2)
  B.SE <- se.coef(model2)
  
  C <- coef(model3)
  C.SE <- se.coef(model3)
  
  D <- coef(model4)
  D.SE <- se.coef(model4)
  
  E <- coef(model5)
  E.SE <- se.coef(model5)	
  
  F <- coef(model6)
  F.SE <- se.coef(model6)	
  
  parm <- matrix(0,nrow=6,ncol=2)
  parm[1,] <- c(A["a"],A.SE["a"])
  parm[2,] <- c(B["a"],B.SE["a"])
  parm[3,] <- c(C["a"],C.SE["a"])
  parm[4,] <- c(D["a"],D.SE["a"])
  parm[5,] <- c(E["a"],E.SE["a"])
  parm[6,] <- c(F["a"],F.SE["a"])
  
  colnames(parm) <- c("beta","se")
  rownames(parm) <- c("Model 1:R,C","Model 2:R,C,X1","Model 3:R,C,X1,X2","Model 4:R,C,X1,X2,X3","Model 5:R,C,X1,X2,X3,M","Model 6:R,C,M")
  
  #A = phi      #1 = a
  #B = gamma    #2 = x1
  #C = eta      #3 = x2
  #D = delta    #4 = x3
  #E = theta    #5 = m
  
  #PRINT INITIAL DISPARITY#
  initial <- matrix(0,nrow=5,ncol=1)
  initial[1,] <- A["a"]
  initial[2,] <- D["a"]
  initial[3,] <- A["a"]
  initial[4,] <- A["a"]
  initial[5,] <- A["a"]
  colnames(initial) <- "Initial Disparity"
  rownames(initial) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT RESIDUAL DISPARITY#
  
  residual <- matrix(0,nrow=5,ncol=1)
  residual[1,] <- D["a"]
  residual[2,] <- E["a"]
  residual[3,] <- E["a"]
  residual[4,] <- (
    E["a"] 
    + 	
      (E["x3"]/D["x3"])*(C["a"]-D["a"])
    + 	
      (
        E["x2"]/C["x2"] + E["x3"]/D["x3"]*(1-D["x2"]/C["x2"])
      )*(B["a"]-C["a"])
    
    + 	
      (
        E["x1"]/B["x1"]+E["x2"]/C["x2"]*(1-C["x1"]/B["x1"])					
        +E["x3"]/D["x3"]*((C["x1"]-D["x1"])/B["x1"]+(1-D["x2"]/C["x2"])*(1-C["x1"]/B["x1"]))
      )*(A["a"]-B["a"])
  )
  residual[5,] <- F["a"]	
  colnames(residual) <- "Residual Disparity"
  rownames(residual) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT DISPARITY REDUCTION#
  
  #A = phi      #1 = a
  #B = gamma    #2 = x1
  #C = eta      #3 = x2
  #D = delta    #4 = x3
  #E = theta    #5 = m
  
  
  reduced <- matrix(0,nrow=5,ncol=1)
  reduced[1,] <- A["a"]-D["a"]
  reduced[2,] <- D["a"]-E["a"]
  reduced[3,] <- A["a"]-E["a"]
  reduced[4,] <- (
    (D["a"]-E["a"]) 
    +
      (1-E["x3"]/D["x3"])*(C["a"]-D["a"])
    + 
      (
        (D["x2"]-E["x2"])/C["x2"] + (1-E["x3"]/D["x3"])*(1-D["x2"]/C["x2"])
      )*(B["a"]-C["a"])
    + 	
      (
        (D["x1"]-E["x1"])/B["x1"]+(D["x2"]-E["x2"])/C["x2"]*(1-C["x1"]/B["x1"])					
        +(1-E["x3"]/D["x3"])*((C["x1"]-D["x1"])/B["x1"]+(1-D["x2"]/C["x2"])*(1-C["x1"]/B["x1"]))
      )*(A["a"]-B["a"])
  )
  reduced[5,] <- A["a"]-F["a"]
  colnames(reduced) <- "Reduced Disparity"
  rownames(reduced) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT PERCENT DISPARITY RESIDUAL#
  
  pct.residual <- matrix(0,nrow=5,ncol=1)	
  pct.residual[1,] <- D["a"]/A["a"]
  pct.residual[2,] <- E["a"]/D["a"]
  pct.residual[3,] <- E["a"]/A["a"]
  pct.residual[4,] <- residual[4,]/A["a"]
  pct.residual[5,] <- F["a"]/A["a"]
  
  #PRINT PERCENT DISPARITY REDUCTION#
  
  pct.reduced <- matrix(0,nrow=5,ncol=1)	
  pct.reduced[1,] <- (A["a"]-D["a"])/A["a"]
  pct.reduced[2,] <- (D["a"]-E["a"])/D["a"]
  pct.reduced[3,] <- (A["a"]-E["a"])/A["a"]
  pct.reduced[4,] <- reduced[4,]/A["a"]
  pct.reduced[5,] <- (A["a"]-F["a"])/A["a"]
  
  #PRINT FINAL RESULT
  
  result <- data.frame(initial,residual,reduced,100*pct.residual,100*pct.reduced)
  result[,1:3] <- round(result[,1:3],3)
  result[,4:5] <- round(result[,4:5],1)
  result[,6] <- c(1,2,3,4,5)
  colnames(result) <- c("Initial","Residual","Reduced","Pct.Residual","Pct.Reduced","Proposition")
  rownames(result) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT INTERIM RESULTS
  
  if (silent=="no") {
    print("Model 1")
    print(rbind(round(A["a"],3),round(A.SE["a"],3)))
    print("Model 2")
    print(rbind(round(B["a"],3),round(B.SE["a"],3)))
    print("Model 3")
    print(rbind(round(C["a"],3),round(C.SE["a"],3)))
    print("Model 4")
    print(rbind(round(D["a"],3),round(D.SE["a"],3)))  
    print("Model 5")
    print(rbind(round(E["a"],3),round(E.SE["a"],3)))  
    print("Model 6")
    print(rbind(round(F["a"],3),round(F.SE["a"],3)))        
    print(parm)
	print(initial)
    print(residual)    
    print(reduced)    
    print(result[,1:5])
  }	else if (silent=="yes") { 
  }  
  
  return(result)
  
} 

decompose.x.bin <- function (indata,year,Y,X1,X1.NA,X2,X2.NA,X3,X3.NA=NULL,M1=NULL,M2=NULL,M.NA=NULL,silent="no") {
  
#    indata=data79
#    year=79
#    Y="unemployed"
#    M1="afqt_std"
#    M2="afqt_std2"
#    M.NA="miss_afqt"
#    X1="educ_mom"
#    X1.NA="miss_educ_mom"
#    X2="hhincome"
#    X2.NA="miss_hhincome"
#    X3="povstatus"
#    X3.NA="miss_povstatus"
  
  if (year==79) {
    
    #RENAME INPUT VARIABLES#
    
    indata <- rename_(indata,y=Y,a="black",w1="age",w2="hispanic",m1=M1,m2=M2,m.na=M.NA,x1=X1,x1.na=X1.NA,x2=X2,x2.na=X2.NA,x3=X3,x3.na=X3.NA)
    indata <- indata %>% subset(w2==0)
        
    #FIT MODELS#
    
    #Fit model 1
    
    model1 <- glm(data=indata, formula= y ~ a
                  +w1, family=binomial("logit"))
    
    #Fit model 2
    
    model2 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  , family=binomial("logit"))
    
    #Fit model 3
    
    model3 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  , family=binomial("logit"))
    
    #Fit model 4
    
    model4 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  , family=binomial("logit"))
    
    #Fit model 5
    
    model5 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  +m1+m2+m.na, family=binomial("logit"))
    
    #Fit model 6 -- Fryer
    
    model6 <- glm(data=indata, formula= y ~ a
                  +w1
                  +m1+m2+m.na, family=binomial("logit"))											
    
  } else if (year==97) {
    
    #	  indata=data97
    #	  year=97
    #	  Y="unemployed"
    #	  M1="afqt_std"
    #	  M2="afqt_std2"
    #	  M.NA="miss_afqt"
    #	  X1="educ_mom"
    #	  X1.NA="miss_educ_mom"
    #	  X2="hhincome"
    #	  X2.NA="miss_hhincome"
    #	  X3="networth"
    #	  X3.NA="miss_networth"
    
    indata <- rename_(indata,y=Y,a="black",w1="age",w2="hispanic",w3="mixed",m1=M1,m2=M2,m.na=M.NA,x1=X1,x1.na=X1.NA,x2=X2,x2.na=X2.NA,x3=X3,x3.na=X3.NA)
    indata <- indata %>% subset(w2==0 & w3==0)
    
    #Fit model 1
    
    model1 <- glm(data=indata, formula= y ~ a
                  +w1, family=binomial("logit"))
    
    #Fit model 2
    
    model2 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  , family=binomial("logit"))
    
    #Fit model 3
    
    model3 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  , family=binomial("logit"))
    #Fit model 4
    
    model4 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  , family=binomial("logit"))										
    
    #Fit model 5
    
    model5 <- glm(data=indata, formula= y ~ a
                  +w1
                  +x1+x1.na
                  +x2+x2.na
                  +x3+x3.na
                  +m1+m2+m.na, family=binomial("logit"))
    
    #Fit model 6
    
    model6 <- glm(data=indata, formula= y ~ a
                  +w1
                  +m1+m2+m.na, family=binomial("logit"))
    
  }
  
  #PRINT RACE PARAMETER#
  
  A <- coef(model1)
  A.SE <- se.coef(model1)
  
  B <- coef(model2)
  B.SE <- se.coef(model2)
  
  C <- coef(model3)
  C.SE <- se.coef(model3)
  
  D <- coef(model4)
  D.SE <- se.coef(model4)
  
  E <- coef(model5)
  E.SE <- se.coef(model5)
  
  F <- coef(model6)
  F.SE <- se.coef(model6)
  
  parm <- matrix(0,nrow=6,ncol=2)
  parm[1,] <- c(A["a"],A.SE["a"])
  parm[2,] <- c(B["a"],B.SE["a"])
  parm[3,] <- c(C["a"],C.SE["a"])
  parm[4,] <- c(D["a"],D.SE["a"])
  parm[5,] <- c(E["a"],E.SE["a"])
  parm[6,] <- c(F["a"],F.SE["a"])
  colnames(parm) <- c("beta","se")
  rownames(parm) <- c("Model 1:R,C","Model 2:R,C,X1","Model 3:R,C,X1,X2","Model 4:R,C,X1,X2,X3","Model 5:R,C,X1,X2,X3,M","Model 6:R,C,M")

  #PRINT INITIAL DISPARITY#
  initial <- matrix(0,nrow=5,ncol=1)
  initial[1,] <- exp(A["a"])
  initial[2,] <- exp(D["a"])
  initial[3,] <- exp(A["a"])
  initial[4,] <- exp(A["a"])
  initial[5,] <- exp(A["a"])
  colnames(initial) <- "Initial Disparity"
  rownames(initial) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT RESIDUAL DISPARITY#
  
  residual <- matrix(0,nrow=5,ncol=1)
  residual[1,] <- exp(D["a"])
  residual[2,] <- exp(E["a"])
  residual[3,] <- exp(E["a"])	
  residual[4,] <- exp(
    E["a"] 
    + 	
      (E["x3"]/D["x3"])*(C["a"]-D["a"])
    + 	
      (
        E["x2"]/C["x2"] + E["x3"]/D["x3"]*(1-D["x2"]/C["x2"])
      )*(B["a"]-C["a"])
    
    + 	
      (
        E["x1"]/B["x1"]+E["x2"]/C["x2"]*(1-C["x1"]/B["x1"])					
        +E["x3"]/D["x3"]*((C["x1"]-D["x1"])/B["x1"]+(1-D["x2"]/C["x2"])*(1-C["x1"]/B["x1"]))
      )*(A["a"]-B["a"])
  )
  residual[5,] <- exp(F["a"])	
  colnames(residual) <- "Residual Disparity"
  rownames(residual) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT DISPARITY REDUCTION#
  
  reduced <- matrix(0,nrow=5,ncol=1)
  reduced[1,] <- exp(A["a"]-D["a"])
  reduced[2,] <- exp(D["a"]-E["a"])
  reduced[3,] <- exp(A["a"]-E["a"])
  reduced[4,] <- exp(
    (D["a"]-E["a"]) 
    +
      (1-E["x3"]/D["x3"])*(C["a"]-D["a"])
    + 
      (
        (D["x2"]-E["x2"])/C["x2"] + (1-E["x3"]/D["x3"])*(1-D["x2"]/C["x2"])
      )*(B["a"]-C["a"])
    + 	
      (
        (D["x1"]-E["x1"])/B["x1"]+(D["x2"]-E["x2"])/C["x2"]*(1-C["x1"]/B["x1"])					
        +(1-E["x3"]/D["x3"])*((C["x1"]-D["x1"])/B["x1"]+(1-D["x2"]/C["x2"])*(1-C["x1"]/B["x1"]))
      )*(A["a"]-B["a"])
  )
  reduced[5,] <- exp(A["a"]-F["a"])	
  colnames(reduced) <- "Reduced Disparity"
  rownames(reduced) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT PERCENT DISPARITY RESIDUAL#
  
  pct.residual <- matrix(0,nrow=5,ncol=1)	
  pct.residual[1,] <- (exp(D["a"])-1)/(exp(A["a"])-1)
  pct.residual[2,] <- (exp(E["a"])-1)/(exp(D["a"])-1)
  pct.residual[3,] <- (exp(E["a"])-1)/(exp(A["a"])-1)
  pct.residual[4,] <- (residual[4,]-1)/(exp(A["a"])-1)
  pct.residual[5,] <- (exp(F["a"])-1)/(exp(A["a"])-1)
  
  #PRINT PERCENT DISPARITY REDUCTION#
  
  pct.reduced <- matrix(0,nrow=5,ncol=1)	
  pct.reduced[1,] <- (exp(A["a"])-exp(D["a"]))/(exp(A["a"])-1)
  pct.reduced[2,] <- (exp(D["a"])-exp(E["a"]))/(exp(D["a"])-1)
  pct.reduced[3,] <- (exp(A["a"])-exp(E["a"]))/(exp(A["a"])-1)
  pct.reduced[4,] <- (exp(A["a"])-residual[4,])/(exp(A["a"])-1)
  pct.reduced[5,] <- (exp(A["a"])-exp(F["a"]))/(exp(A["a"])-1)
  
  #PRINT FINAL RESULTS
  
  result <- data.frame(initial,residual,reduced,100*pct.residual,100*pct.reduced)
  result[,1:3] <- round(result[,1:3],3)
  result[,4:5] <- round(result[,4:5],1)
  result[,6] <- c(1,2,3,4,5)
  colnames(result) <- c("Initial","Residual","Reduced","Pct.Residual","Pct.Reduced","Proposition")
  rownames(result) <- c("Prop 1","Prop 2","Prop 3","Prop 4","Fryer")
  
  #PRINT INTERIM RESULTS
  
  if (silent=="no") {
    print("Model 1")
    print(rbind(round(A["a"],3),round(A.SE["a"],3)))
    print("Model 2")
    print(rbind(round(B["a"],3),round(B.SE["a"],3)))
    print("Model 3")
    print(rbind(round(C["a"],3),round(C.SE["a"],3)))
    print("Model 4")
    print(rbind(round(D["a"],3),round(D.SE["a"],3)))        
    print("Model 5")
    print(rbind(round(E["a"],3),round(E.SE["a"],3))) 
    print("Model 6")
    print(rbind(round(F["a"],3),round(F.SE["a"],3))) 	  
    
    print(parm)
	print(initial)
    print(residual)    
    print(reduced)    
    print(result[,1:5])
  }	else if (silent=="yes") { 
  }  
  
  return(result)
  
} 

decompose.x.boot <- function (data,y.name,m1.name,m2.name,m.na.name,x1.name,x1.na.name,x2.name,x2.na.name,x3.name,x3.na.name,times,year,type) {
  
  output <- list()
  
  for (i in 1:times) {
    
    dataset <- data[sample(1:nrow(data),nrow(data),replace=TRUE),]
    
    if (type=="continuous") {
      
      output[[i]] <- decompose.x.con(indata=dataset,Y=y.name,M1=m1.name,M2=m2.name,M.NA=m.na.name,X1=x1.name,X1.NA=x1.na.name,X2=x2.name,X2.NA=x2.na.name,X3=x3.name,X3.NA=x3.na.name,year=year,silent="yes")
      
    } else if (type=="binary") {
      
      output[[i]] <- decompose.x.bin(indata=dataset,Y=y.name,M1=m1.name,M2=m2.name,M.NA=m.na.name,X1=x1.name,X1.NA=x1.na.name,X2=x2.name,X2.NA=x2.na.name,X3=x3.name,X3.NA=x3.na.name,year=year,silent="yes")
      
    }
    
  }
  
  collapsed.output <- data.frame(bind_rows(output))
  
  lower <- function (x) quantile(x,.025,na.rm=TRUE)
  upper <- function (x) quantile(x,.975,na.rm=TRUE)
  
  if (type=="continuous") {
  
  processed.output <- collapsed.output %>% 
    group_by(Proposition) %>%
    summarize( 
      ini.est=mean(Initial),
      ini.se=sd(Initial),
      ini.lower=lower(Initial),
      ini.upper=upper(Initial),
      res.est=mean(Residual),
      res.se=sd(Residual),
      res.lower=lower(Residual),
      res.upper=upper(Residual),
      red.est=mean(Reduced),
      red.se=sd(Reduced),
      red.lower=lower(Reduced),
      red.upper=upper(Reduced)
    ) %>% data.frame()
	
	} else if (type=="binary") {
	
  processed.output <- collapsed.output %>% 
    group_by(Proposition) %>%
    summarize( 
      ini.est=exp(mean(log(Initial))),
      ini.se=exp(sd(log(Initial))),
      ini.lower=exp(lower(log(Initial))),
      ini.upper=exp(upper(log(Initial))),
      res.est=exp(mean(log(Residual))),
      res.se=exp(sd(log(Residual))),
      res.lower=exp(lower(log(Residual))),
      res.upper=exp(upper(log(Residual))),
      red.est=exp(mean(log(Reduced))),
      red.se=exp(sd(log(Reduced))),
      red.lower=exp(lower(log(Reduced))),
      red.upper=exp(upper(log(Reduced)))
    ) %>% data.frame()	
	
	}
  
  print(round(processed.output,3))
  
}

#################################
########AFQT TEST SCORES#########
#################################

#MODEL-BASED S.E.

print("LOG WAGES 79, TEST SCORES, MODEL SE")
decompose.x.con(indata=data79,year=79,Y="logwages",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt")
#print("UNEMPLOYMENT 79, TEST SCORES, MODEL SE")
#decompose.x.bin(indata=data79,year=79,Y="unemployed",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt") 
print("PRISON 79, TEST SCORES, MODEL SE")
decompose.x.bin(indata=data79,year=79,Y="prison",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt")
print("HEALTH 79, TEST SCORES, MODEL SE")
decompose.x.con(indata=data79,year=79,Y="health",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt") 
print("LOG WAGES 97, TEST SCORES, MODEL SE")
decompose.x.con(indata=data97,year=97,Y="logwages",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="networth",X3.NA="miss_networth",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt") 
#print("UNEMPLOYMENT 97, TEST SCORES, MODEL SE")
#decompose.x.bin(indata=data97,year=97,Y="unemployed",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="networth",X3.NA="miss_networth",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt") 
print("PRISON 97, TEST SCORES, MODEL SE")
decompose.x.bin(indata=data97,year=97,Y="prison",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="networth",X3.NA="miss_networth",M1="afqt_std",M2="afqt_std2",M.NA="miss_afqt") 

#BOOTSTRAP S.E.

print("BOOT LOG WAGES 79, TEST SCORES, BOOTSTRAP SE")  
decompose.x.boot(data=data79,year=79,y.name="logwages",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="continuous",times=1000)  
#print("BOOT UNEMPLOYMENT 79, TEST SCORES, BOOTSTRAP SE") 
#decompose.x.boot(data=data79,year=79,y.name="unemployed",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="binary",times=1000) 
print("BOOT PRISON 79, TEST SCORES, BOOTSTRAP SE") 
decompose.x.boot(data=data79,year=79,y.name="prison",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="binary",times=1000) 
print("BOOT HEALTH 79, TEST SCORES, BOOTSTRAP SE") 
decompose.x.boot(data=data79,year=79,y.name="health",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="continuous",times=1000)
print("BOOT LOG WAGES 97, TEST SCORES, BOOTSTRAP SE") 
decompose.x.boot(data=data97,year=97,y.name="logwages",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="networth",x3.na.name="miss_networth",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="continuous",times=1000) 
#print("BOOT UNEMPLOYMENT 97, TEST SCORES, BOOTSTRAP SE") 
#decompose.x.boot(data=data97,year=97,y.name="unemployed",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="networth",x3.na.name="miss_networth",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="binary",times=1000) 
print("BOOT PRISON 97, TEST SCORES, BOOTSTRAP SE") 
decompose.x.boot(data=data97,year=97,y.name="prison",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="networth",x3.na.name="miss_networth",m1.name="afqt_std",m2.name="afqt_std2",m.na.name="miss_afqt",type="binary",times=1000)  



######################################
########TOTAL YEARS EDUCATION#########
######################################

#MODEL-BASED S.E.

print("LOG WAGES 79, YRS EDUCATION, MODEL SE")
decompose.x.con(indata=data79,year=79,Y="logwages",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade")
print("UNEMPLOYMENT 79, YRS EDUCATION, MODEL SE")
decompose.x.bin(indata=data79,year=79,Y="unemployed",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade") 
print("PRISON 79, YRS EDUCATION, MODEL SE")
decompose.x.bin(indata=data79,year=79,Y="prison",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade")
print("HEALTH 79, YRS EDUCATION, MODEL SE")
decompose.x.con(indata=data79,year=79,Y="health",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="povstatus",X3.NA="miss_povstatus",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade") 
print("LOG WAGES 97, YRS EDUCATION, MODEL SE")
decompose.x.con(indata=data97,year=97,Y="logwages",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="networth",X3.NA="miss_networth",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade") 
#print("UNEMPLOYMENT 97, YRS EDUCATION, MODEL SE")
#decompose.x.bin(indata=data97,year=97,Y="unemployed",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="networth",X3.NA="miss_networth",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade") 
print("PRISON 97, YRS EDUCATION, MODEL SE")
decompose.x.bin(indata=data97,year=97,Y="prison",X1="educ_mom",X1.NA="miss_educ_mom",X2="hhincome",X2.NA="miss_hhincome",X3="networth",X3.NA="miss_networth",M1="highgrade",M2="highgrade2",M.NA="miss_highgrade") 

#BOOTSTRAP S.E.

print("BOOT LOG WAGES 79, YRS EDUCATION, BOOTSTRAP SE")
decompose.x.boot(data=data79,year=79,y.name="logwages",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="continuous",times=1000)
print("BOOT UNEMPLOYMENT 79, YRS EDUCATION, BOOTSTRAP SE")
decompose.x.boot(data=data79,year=79,y.name="unemployed",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="binary",times=1000)
print("BOOT PRISON 79, YRS EDUCATION, BOOTSTRAP SE")
decompose.x.boot(data=data79,year=79,y.name="prison",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="binary",times=1000)
print("BOOT HEALTH 79, YRS EDUCATION, BOOTSTRAP SE")
decompose.x.boot(data=data79,year=79,y.name="health",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="povstatus",x3.na.name="miss_povstatus",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="continuous",times=1000)
print("BOOT LOG WAGES 97, YRS EDUCATION, BOOTSTRAP SE")
decompose.x.boot(data=data97,year=97,y.name="logwages",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="networth",x3.na.name="miss_networth",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="continuous",times=1000)
#print("BOOT UNEMPLOYMENT 97, YRS EDUCATION, BOOTSTRAP SE")
#decompose.x.boot(data=data97,year=97,y.name="unemployed",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="networth",x3.na.name="miss_networth",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="binary",times=1000)
print("BOOT PRISON 97, YRS EDUCATION, BOOTSTRAP SE")
decompose.x.boot(data=data97,year=97,y.name="prison",x1.name="educ_mom",x1.na.name="miss_educ_mom",x2.name="hhincome",x2.na.name="miss_hhincome",x3.name="networth",x3.na.name="miss_networth",m1.name="highgrade",m2.name="highgrade2",m.na.name="miss_highgrade",type="binary",times=1000) 


sink()

